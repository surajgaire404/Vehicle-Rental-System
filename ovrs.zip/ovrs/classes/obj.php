<?php

$glist=$obj->getMedia6();
$vlist1=$obj->getVideo();
$alist=$obj->getAlist('tbl_albums');
$vlist=$obj->getVideoall();
?>