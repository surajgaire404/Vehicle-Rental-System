<?php 
include("function.php");
date_default_timezone_set('Asia/Kathmandu');
$obj=new Functions();
session_start();
$today = date("F j, Y, g:i a"); 
$ach=date("F Y"); 
?>