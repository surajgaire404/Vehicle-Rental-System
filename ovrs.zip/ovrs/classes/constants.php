<?php
define("SERVERNAME","localhost");
define("USER","root");
define("PASSWORD","");
// Database infomation
define("DATABASE","ovrs");
//Table  Information
define("ADMIN","tbl_register");
define("VEHICAL","tbl_vehical");



?>