<?php

$v = $_POST['id'];
echo json_encode($v);
